import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { Button } from "../components/common/Button";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function CollectionsScreen({ navigation }) {
  const [collections, setCollections] = useState([]);

  useEffect(() => {
    loadCollections();
  }, []);

  const loadCollections = async () => {
    const savedCollections = await storage.getCollections();
    setCollections(savedCollections);
  };

  const renderCollectionItem = ({ item }) => (
    <TouchableOpacity
      style={styles.collectionItem}
      onPress={() =>
        navigation.navigate("CollectionDetail", { collectionId: item.id })
      }
    >
      <Text style={styles.collectionName}>{item.name}</Text>
      <View style={styles.collectionStats}>
        <Text style={styles.statsText}>{item.shops?.length || 0} shops</Text>
        <Text style={styles.statsText}>
          {item.trips?.length || 0} trips completed
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={collections}
        renderItem={renderCollectionItem}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No collections created yet.</Text>
        }
      />
      <Button
        title="Create New Collection"
        onPress={() => navigation.navigate("AddCollection")}
        style={styles.addButton}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  collectionItem: {
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.md,
    marginHorizontal: theme.spacing.md,
    marginVertical: theme.spacing.sm,
    borderRadius: 8,
  },
  collectionName: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: theme.spacing.sm,
  },
  collectionStats: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  statsText: {
    color: theme.colors.textSecondary,
    fontSize: 14,
  },
  emptyText: {
    color: theme.colors.textSecondary,
    textAlign: "center",
    marginTop: theme.spacing.xl,
  },
  addButton: {
    margin: theme.spacing.md,
  },
});
