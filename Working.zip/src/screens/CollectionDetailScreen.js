import React, { useState, useEffect } from "react";
import { View, StyleSheet } from "react-native";
import { TabBar } from "../components/common/TabBar";
import { CollectionShopsTab } from "../components/collection/CollectionShopsTab";
import { CollectionTripsTab } from "../components/collection/CollectionTripsTab";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function CollectionDetailScreen({ route, navigation }) {
  const { collectionId } = route.params;
  const [collection, setCollection] = useState(null);
  const [activeTab, setActiveTab] = useState("shops");

  useEffect(() => {
    loadCollection();
  }, []);

  const loadCollection = async () => {
    const collectionData = await storage.getCollectionById(collectionId);
    setCollection(collectionData);

    // Set screen title
    navigation.setOptions({ title: collectionData.name });
  };

  const refreshCollection = () => {
    loadCollection();
  };

  return (
    <View style={styles.container}>
      <TabBar
        tabs={[
          { key: "shops", title: "Shops" },
          { key: "history", title: "Trip History" },
        ]}
        activeTab={activeTab}
        onTabPress={setActiveTab}
      />

      {activeTab === "shops" ? (
        <CollectionShopsTab
          collection={collection}
          onRefresh={refreshCollection}
          navigation={navigation}
        />
      ) : (
        <CollectionTripsTab
          collection={collection}
          onRefresh={refreshCollection}
          navigation={navigation}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
});
