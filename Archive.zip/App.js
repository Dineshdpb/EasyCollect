import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import HomeScreen from "./src/screens/HomeScreen";
import TripScreen from "./src/screens/TripScreen";
import AddTripScreen from "./src/screens/AddTripScreen";
import TripDetailScreen from "./src/screens/TripDetailScreen";
import AddShopScreen from "./src/screens/AddShopScreen";
import StartTripScreen from "./src/screens/StartTripScreen";
import UpdateShopStatusScreen from "./src/screens/UpdateShopStatusScreen";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Stack.Navigator
          initialRouteName="Trips"
          screenOptions={{
            headerStyle: {
              backgroundColor: "#1a1a1a",
            },
            headerTintColor: "#fff",
            headerTitleStyle: {
              fontWeight: "bold",
            },
          }}
        >
          <Stack.Screen
            name="Home"
            component={HomeScreen}
            options={{ title: "Collections" }}
          />
          <Stack.Screen
            name="Trips"
            component={TripScreen}
            options={{ title: "My Trips" }}
          />
          <Stack.Screen
            name="AddTrip"
            component={AddTripScreen}
            options={{ title: "Add New Trip" }}
          />
          <Stack.Screen
            name="TripDetail"
            component={TripDetailScreen}
            options={{ title: "Trip Details" }}
          />
          <Stack.Screen
            name="AddShop"
            component={AddShopScreen}
            options={{ title: "Add Shop" }}
          />
          <Stack.Screen
            name="StartTrip"
            component={StartTripScreen}
            options={{ title: "Active Trip" }}
          />
          <Stack.Screen
            name="UpdateShopStatus"
            component={UpdateShopStatusScreen}
            options={{ title: "Update Shop" }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
