import React, { useState } from "react";
import { View, TextInput, StyleSheet, Alert, ScrollView } from "react-native";
import { Button } from "../components/common/Button";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function AddShopScreen({ route, navigation }) {
  const { tripId } = route.params;
  const [shopName, setShopName] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");

  const handleSaveShop = async () => {
    if (!shopName.trim()) {
      Alert.alert("Error", "Please enter a shop name");
      return;
    }

    const newShop = {
      id: Date.now().toString(),
      name: shopName.trim(),
      address: address.trim(),
      notes: notes.trim(),
      visitDate: new Date().toISOString(),
    };

    const trips = await storage.getTrips();
    const updatedTrips = trips.map((trip) => {
      if (trip.id === tripId) {
        return {
          ...trip,
          shops: [...(trip.shops || []), newShop],
        };
      }
      return trip;
    });

    await storage.saveTrips(updatedTrips);
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Shop Name"
        placeholderTextColor={theme.colors.textSecondary}
        value={shopName}
        onChangeText={setShopName}
      />
      <TextInput
        style={styles.input}
        placeholder="Address"
        placeholderTextColor={theme.colors.textSecondary}
        value={address}
        onChangeText={setAddress}
        multiline
      />
      <TextInput
        style={[styles.input, styles.notesInput]}
        placeholder="Notes"
        placeholderTextColor={theme.colors.textSecondary}
        value={notes}
        onChangeText={setNotes}
        multiline
      />
      <Button
        title="Save Shop"
        onPress={handleSaveShop}
        style={styles.saveButton}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing.md,
  },
  input: {
    backgroundColor: theme.colors.surface,
    color: theme.colors.text,
    padding: theme.spacing.md,
    borderRadius: 8,
    fontSize: 16,
    marginBottom: theme.spacing.md,
  },
  notesInput: {
    height: 100,
    textAlignVertical: "top",
  },
  saveButton: {
    marginTop: theme.spacing.md,
  },
});
