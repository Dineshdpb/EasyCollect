import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, Alert } from "react-native";
import { Button } from "../components/common/Button";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function StartTripScreen({ route, navigation }) {
  const { tripId } = route.params;
  const [currentTrip, setCurrentTrip] = useState(null);
  const [currentShopIndex, setCurrentShopIndex] = useState(0);
  const [currentShop, setCurrentShop] = useState(null);

  useEffect(() => {
    loadTripDetails();
  }, []);

  const loadTripDetails = async () => {
    const trips = await storage.getTrips();
    const trip = trips.find((t) => t.id === tripId);
    if (trip && trip.shops && trip.shops.length > 0) {
      setCurrentTrip(trip);
      setCurrentShop(trip.shops[0]);
    } else {
      Alert.alert("No Shops", "This trip has no shops to visit.");
      navigation.goBack();
    }
  };

  const handleShopUpdate = () => {
    navigation.navigate("UpdateShopStatus", {
      tripId,
      shopId: currentShop.id,
      onUpdate: handleShopStatusUpdated,
    });
  };

  const handleShopStatusUpdated = async () => {
    if (currentShopIndex < currentTrip.shops.length - 1) {
      setCurrentShopIndex((prev) => prev + 1);
      setCurrentShop(currentTrip.shops[currentShopIndex + 1]);
    } else {
      Alert.alert("Trip Complete", "You have visited all shops in this trip!");
      navigation.navigate("TripDetail", { tripId });
    }
  };

  const handleStopTrip = () => {
    Alert.alert("Stop Trip", "Are you sure you want to stop this trip?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Stop",
        style: "destructive",
        onPress: () => navigation.navigate("TripDetail", { tripId }),
      },
    ]);
  };

  if (!currentShop) return null;

  return (
    <View style={styles.container}>
      <View style={styles.shopCard}>
        <Text style={styles.shopCount}>
          Shop {currentShopIndex + 1} of {currentTrip?.shops.length}
        </Text>
        <Text style={styles.shopName}>{currentShop.name}</Text>
        <Text style={styles.shopAddress}>{currentShop.address}</Text>
        {currentShop.notes && (
          <Text style={styles.notes}>Notes: {currentShop.notes}</Text>
        )}
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="Update Shop Status"
          onPress={handleShopUpdate}
          style={styles.updateButton}
        />
        <Button
          title="Stop Trip"
          onPress={handleStopTrip}
          style={styles.stopButton}
          textStyle={styles.stopButtonText}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing.md,
  },
  shopCard: {
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.lg,
    borderRadius: 12,
    marginBottom: theme.spacing.lg,
  },
  shopCount: {
    color: theme.colors.primary,
    fontSize: 14,
    marginBottom: theme.spacing.sm,
  },
  shopName: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: theme.spacing.sm,
  },
  shopAddress: {
    color: theme.colors.textSecondary,
    fontSize: 16,
    marginBottom: theme.spacing.sm,
  },
  notes: {
    color: theme.colors.textSecondary,
    fontSize: 14,
    fontStyle: "italic",
  },
  buttonContainer: {
    marginTop: "auto",
  },
  updateButton: {
    marginBottom: theme.spacing.md,
  },
  stopButton: {
    backgroundColor: theme.colors.error,
  },
  stopButtonText: {
    color: theme.colors.text,
  },
});
