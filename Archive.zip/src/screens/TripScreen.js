import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { Button } from "../components/common/Button";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function TripScreen({ navigation }) {
  const [trips, setTrips] = useState([]);

  useEffect(() => {
    loadTrips();
  }, []);

  const loadTrips = async () => {
    const savedTrips = await storage.getTrips();
    setTrips(savedTrips);
  };

  const handleAddTrip = () => {
    navigation.navigate("AddTrip");
  };

  const renderTrip = ({ item }) => (
    <TouchableOpacity
      style={styles.tripItem}
      onPress={() => navigation.navigate("TripDetail", { tripId: item.id })}
    >
      <Text style={styles.tripName}>{item.name}</Text>
      <Text style={styles.tripDate}>
        {new Date(item.date).toLocaleDateString()}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={trips}
        renderItem={renderTrip}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            No trips yet. Start by adding one!
          </Text>
        }
      />
      <Button
        title="Add New Trip"
        onPress={handleAddTrip}
        style={styles.addButton}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing.md,
  },
  tripItem: {
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.md,
    borderRadius: 8,
    marginBottom: theme.spacing.sm,
  },
  tripName: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: "600",
  },
  tripDate: {
    color: theme.colors.textSecondary,
    fontSize: 14,
    marginTop: theme.spacing.xs,
  },
  emptyText: {
    color: theme.colors.textSecondary,
    textAlign: "center",
    marginTop: theme.spacing.xl,
  },
  addButton: {
    marginTop: theme.spacing.md,
  },
});
