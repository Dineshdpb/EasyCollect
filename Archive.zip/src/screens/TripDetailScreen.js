import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";
import { Button } from "../components/common/Button";
import { storage } from "../storage/asyncStorage";
import { theme } from "../theme";

export default function TripDetailScreen({ route, navigation }) {
  const { tripId } = route.params;
  const [trip, setTrip] = useState(null);

  useEffect(() => {
    loadTripDetails();
  }, []);

  const loadTripDetails = async () => {
    const trips = await storage.getTrips();
    const currentTrip = trips.find((t) => t.id === tripId);
    setTrip(currentTrip);
  };

  const handleAddShop = () => {
    navigation.navigate("AddShop", { tripId });
  };

  const renderShop = ({ item }) => (
    <View style={styles.shopItem}>
      <Text style={styles.shopName}>{item.name}</Text>
      <Text style={styles.shopAddress}>{item.address}</Text>
      <Text style={styles.visitDate}>
        Visited: {new Date(item.visitDate).toLocaleDateString()}
      </Text>
    </View>
  );

  if (!trip) return null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.tripName}>{trip.name}</Text>
        <Text style={styles.tripDate}>
          {new Date(trip.date).toLocaleDateString()}
        </Text>
      </View>
      <Button
        title="Start Trip"
        onPress={() => navigation.navigate("StartTrip", { tripId: trip.id })}
        style={styles.startTripButton}
      />
      <FlatList
        data={trip.shops}
        renderItem={renderShop}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            No shops visited yet. Add your first shop!
          </Text>
        }
      />
      <Button
        title="Add Shop"
        onPress={handleAddShop}
        style={styles.addButton}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing.md,
  },
  header: {
    marginBottom: theme.spacing.lg,
  },
  tripName: {
    color: theme.colors.text,
    fontSize: 24,
    fontWeight: "bold",
  },
  tripDate: {
    color: theme.colors.textSecondary,
    fontSize: 16,
  },
  shopItem: {
    backgroundColor: theme.colors.surface,
    padding: theme.spacing.md,
    borderRadius: 8,
    marginBottom: theme.spacing.sm,
  },
  shopName: {
    color: theme.colors.text,
    fontSize: 18,
    fontWeight: "600",
  },
  shopAddress: {
    color: theme.colors.textSecondary,
    fontSize: 14,
    marginTop: theme.spacing.xs,
  },
  visitDate: {
    color: theme.colors.textSecondary,
    fontSize: 12,
    marginTop: theme.spacing.xs,
  },
  emptyText: {
    color: theme.colors.textSecondary,
    textAlign: "center",
    marginTop: theme.spacing.xl,
  },
  addButton: {
    marginTop: theme.spacing.md,
  },
  startTripButton: {
    marginBottom: theme.spacing.md,
    backgroundColor: theme.colors.success,
  },
});
