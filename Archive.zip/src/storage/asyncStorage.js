import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEYS = {
  TRIPS: "@trips",
  CURRENT_TRIP: "@current_trip",
};

export const storage = {
  async getTrips() {
    try {
      const trips = await AsyncStorage.getItem(STORAGE_KEYS.TRIPS);
      return trips ? JSON.parse(trips) : [];
    } catch (error) {
      console.error("Error getting trips:", error);
      return [];
    }
  },

  async saveTrips(trips) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.TRIPS, JSON.stringify(trips));
    } catch (error) {
      console.error("Error saving trips:", error);
    }
  },

  async getCurrentTrip() {
    try {
      const currentTrip = await AsyncStorage.getItem(STORAGE_KEYS.CURRENT_TRIP);
      return currentTrip ? JSON.parse(currentTrip) : null;
    } catch (error) {
      console.error("Error getting current trip:", error);
      return null;
    }
  },

  async saveCurrentTrip(trip) {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.CURRENT_TRIP,
        JSON.stringify(trip)
      );
    } catch (error) {
      console.error("Error saving current trip:", error);
    }
  },
};
